window.SLM = window.SLM || {};
window.SLM['stage/custom-page-common/index.js'] = window.SLM['stage/custom-page-common/index.js'] || function () {
  const _exports = {};
  return _exports;
}();